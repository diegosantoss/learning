import React, { Component } from "react";

class LazyComponent extends Component {
  render() {
    return <div>Lazy Component</div>;
  }
}

export default LazyComponent;

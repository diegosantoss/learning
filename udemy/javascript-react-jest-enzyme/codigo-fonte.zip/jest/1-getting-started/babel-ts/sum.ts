export function sum(a: number, b: number) {
  return a + b;
}

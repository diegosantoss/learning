module.exports = function() {
  // some implementation;
};

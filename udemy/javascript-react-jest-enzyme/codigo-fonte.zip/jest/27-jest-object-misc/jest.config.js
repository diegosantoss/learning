module.exports = {
  testRunner: "jest-circus/runner"
};

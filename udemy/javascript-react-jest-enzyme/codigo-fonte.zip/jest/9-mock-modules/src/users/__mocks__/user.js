module.exports = {
  name: "Mock User"
};

module.exports = {
  myHeavyTask: args => {
    return args;
  }
};

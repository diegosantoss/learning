module.exports = class SoundPlayer {
  constructor() {
    console.log("Mock SoundPlayer: constructor was called");
  }

  playSoundFile() {
    console.log("Mock SoundPlayer: playSoundFile was called");
  }
};

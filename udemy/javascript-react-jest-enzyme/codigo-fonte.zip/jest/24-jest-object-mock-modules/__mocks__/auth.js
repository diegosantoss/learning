module.exports = {
  authorize() {
    return "mock";
  }
};

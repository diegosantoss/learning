module.exports = {
  authorize() {
    return "original";
  }
};

module.exports = {
  automock: false
};

module.exports = {
  preset: "@shelf/jest-dynamodb"
};

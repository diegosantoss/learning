module.exports = {
  resolver: "./resolver"
};

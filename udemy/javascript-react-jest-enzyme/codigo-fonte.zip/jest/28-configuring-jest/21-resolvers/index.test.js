test("foo", () => {
  expect(require("foo")).toBe("foo");
});

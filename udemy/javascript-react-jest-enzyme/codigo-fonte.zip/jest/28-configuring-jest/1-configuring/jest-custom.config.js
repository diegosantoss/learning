const { defaults } = require("jest-config");

console.log(defaults);

module.exports = {
  verbose: true
};

module.exports = {
  automock: true,
  globals: {
    __DEV__: {
      mutateMe: true
    }
  }
};

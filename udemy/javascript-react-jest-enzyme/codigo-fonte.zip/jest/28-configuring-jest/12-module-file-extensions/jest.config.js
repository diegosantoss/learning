module.exports = {
  moduleDirectories: ["node_modules", "custom_node_modules"],
  moduleFileExtensions: ["json", "js"]
};

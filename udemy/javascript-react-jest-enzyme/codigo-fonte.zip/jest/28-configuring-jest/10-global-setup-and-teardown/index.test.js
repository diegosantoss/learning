test("global", () => {
  // expect(__DEV__).toBeUndefined();
});

module.exports = {
  automock: true,
  globalSetup: "<rootDir>/setup.js",
  globalTeardown: "<rootDir>/teardown.js"
};

module.exports = async () => {
  global.__DEV__ = true;
};

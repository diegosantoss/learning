module.exports = {
  restoreMocks: true
};

module.exports = {
  resetModules: true
};

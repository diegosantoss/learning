module.exports = {
  dependencyExtractor: "<rootDir>/dependencyExtractor"
};

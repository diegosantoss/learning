module.exports = {
  preset: "./notify-preset/jest-preset.js"
};

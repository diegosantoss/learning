module.exports = {
  clearMocks: true
};

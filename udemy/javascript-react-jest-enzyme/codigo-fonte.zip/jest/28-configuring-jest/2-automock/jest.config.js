module.exports = {
  automock: true
};

module.exports = {
  cacheDirectory: "<rootDir>/cache"
};

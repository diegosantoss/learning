module.exports = {
  modulePaths: ["<rootDir>/src"],
  modulePathIgnorePatterns: ["<rootDir>/src/ignore"]
};

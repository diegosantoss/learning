test("ignore", () => {
  expect(require("ignore/custom-module")).toBe("custom-module");
});

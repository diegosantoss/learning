test("accept/custom-module", () => {
  expect(require("accept/custom-module")).toBe("custom-module");
});

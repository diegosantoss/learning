module.exports = {
  // testMatch: ["**/__secret_tests__/**/*.[jt]s?(x)"]
  // testPathIgnorePatterns: ["__secret_tests__"]
  testRegex: "__secret_tests__"
};

module.exports = {
  automock: true,
  displayName: {
    name: "ScaffoldHub",
    color: "blue"
  }
};

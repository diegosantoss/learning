test('snapshot-resolver', () => {
  expect("foo").toMatchSnapshot();
});
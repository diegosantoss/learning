module.exports = results => {
  // console.log(results);
  results.success = true;
  return results;
};

module.exports = {
  toUpperCase(arg) {
    return arg && arg.toUpperCase();
  },

  toLowerCase(arg) {
    return arg && arg.toLowerCase();
  }
};

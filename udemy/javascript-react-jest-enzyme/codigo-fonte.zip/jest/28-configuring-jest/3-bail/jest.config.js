module.exports = {
  bail: true
};

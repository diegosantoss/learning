test("bail", () => {
  throw new Error("error");
});

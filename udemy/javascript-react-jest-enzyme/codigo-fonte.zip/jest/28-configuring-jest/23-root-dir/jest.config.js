module.exports = {
  rootDir: "./src",
  globalSetup: "<rootDir>/globalSetup.js",
  globalTeardown: "<rootDir>/globalTeardown.js"
};

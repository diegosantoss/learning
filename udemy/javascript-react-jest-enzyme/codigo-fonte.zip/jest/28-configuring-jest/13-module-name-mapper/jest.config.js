module.exports = {
  moduleNameMapper: {
    "^[./a-zA-Z0-9$_-]+\\.png$": "<rootDir>/image-stub.js"
  }
};

module.exports = "image-stub";

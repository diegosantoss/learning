test("custom-module", () => {
  expect(require("custom-module")).toBe("custom-module");
});

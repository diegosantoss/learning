module.exports = {
  reporters: [
    // "default",
    ["<rootDir>/my-custom-reporter.js", { banana: "yes", pineapple: "no" }]
  ]
};

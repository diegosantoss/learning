module.exports = {
  runner: "jest-runner-prettier"
}
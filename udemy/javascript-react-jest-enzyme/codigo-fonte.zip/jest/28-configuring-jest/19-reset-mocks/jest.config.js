module.exports = {
  resetMocks: true
};

test("location.href", () => {
  expect(location.href).toBe("https://scaffoldhub.io/");
});

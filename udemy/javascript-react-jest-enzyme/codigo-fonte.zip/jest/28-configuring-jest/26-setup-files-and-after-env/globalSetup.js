module.exports = async () => {
  console.log("GLOBAL SETUP");
};

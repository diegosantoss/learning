module.exports = {
  globalSetup: "<rootDir>/globalSetup.js",
  globalTeardown: "<rootDir>/globalTeardown.js",
  setupFiles: ["<rootDir>/setup.js"],
  setupFilesAfterEnv: ["<rootDir>/setupAfterEnv.js"]
};

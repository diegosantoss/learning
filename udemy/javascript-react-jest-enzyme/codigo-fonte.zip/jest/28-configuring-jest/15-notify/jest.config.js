module.exports = {
  notify: true,
  notifyMode: "failure"
};

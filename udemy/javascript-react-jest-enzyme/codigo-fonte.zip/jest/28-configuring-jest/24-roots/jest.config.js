module.exports = {
  roots: ["<rootDir>/tests"]
};

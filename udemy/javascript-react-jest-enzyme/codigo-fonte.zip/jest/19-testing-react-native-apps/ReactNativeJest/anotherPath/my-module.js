export default "my-module-at-another-path";

import myModule from "./my-module";

console.log("Setting up test");
console.log(myModule);

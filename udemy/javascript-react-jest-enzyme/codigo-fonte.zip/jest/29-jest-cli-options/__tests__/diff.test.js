test("diff", () => {
  expect({ bar: "foo" }).toEqual({ foo: "bar" });
});

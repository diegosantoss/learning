test("a", () => {
  expect(require("../src/a")).toBe("a");
});

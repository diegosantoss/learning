test("snapshot", () => {
  expect("bar").toMatchSnapshot();
});

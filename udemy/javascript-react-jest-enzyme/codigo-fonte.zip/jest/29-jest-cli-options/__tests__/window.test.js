test("window", () => {
  expect(window).toBeDefined();
});

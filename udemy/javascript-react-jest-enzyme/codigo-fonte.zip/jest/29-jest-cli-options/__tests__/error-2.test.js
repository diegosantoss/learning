test("error", () => {
  throw new Error("error");
});

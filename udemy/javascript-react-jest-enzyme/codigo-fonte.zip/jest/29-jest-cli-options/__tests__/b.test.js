test("b", () => {
  expect(require("../src/b")).toBe("b");
});
